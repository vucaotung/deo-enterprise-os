# 🚀 QUICK START: Deploy Your AI Second Brain (7-Day Guide)

**Objective:** Get your system running and processing knowledge by end of week  
**Time Commitment:** 1-2 hours per day for 7 days  
**Success Metric:** First assets generated from RAG-enriched synthesis  

---

## 📅 Day-by-Day Implementation

### **DAY 1 (Monday): Foundation Setup - 90 Minutes**

#### **Task 1.1: Create Folder Structure (20 min)**
```bash
# On your machine, create this structure:

second_brain/
├── raw/
│   ├── articles/
│   ├── case_studies/
│   ├── transcripts/
│   ├── pdfs/
│   └── web_clips/
├── wiki/
│   ├── 01_AI_and_LLMs/
│   ├── 02_Marketing_and_Automation/
│   ├── 03_Tools_and_Integrations/
│   ├── 04_Business_Models/
│   ├── INDEX.md
│   ├── BACKLINKS.md
│   └── CONTRADICTIONS.md
├── prompts/
│   ├── 01_content_generation/
│   ├── 02_analysis_and_synthesis/
│   └── 03_automation_design/
├── playbooks/
│   ├── 01_lead_generation/
│   ├── 02_content_production/
│   └── 03_customer_operations/
├── tools/
│   ├── 01_ai_platforms/
│   ├── 02_automation/
│   └── 03_databases_and_storage/
├── outputs/
│   ├── 01_reports/
│   ├── 02_roadmaps/
│   └── 03_presentations/
├── tools_internal/
│   ├── PROCESSING_LOG.md
│   ├── HEALTH_CHECK.md
│   └── ASSET_MATRIX.md
└── CLAUDE.md
```

**How to do it:**
```bash
# Using terminal/command line:
cd ~/Documents  # or wherever you want
mkdir -p second_brain/raw/{articles,case_studies,transcripts,pdfs,web_clips}
mkdir -p second_brain/wiki/{01_AI_and_LLMs,02_Marketing_and_Automation,03_Tools_and_Integrations,04_Business_Models}
mkdir -p second_brain/prompts/{01_content_generation,02_analysis_and_synthesis,03_automation_design}
mkdir -p second_brain/playbooks/{01_lead_generation,02_content_production,03_customer_operations}
mkdir -p second_brain/tools/{01_ai_platforms,02_automation,03_databases_and_storage}
mkdir -p second_brain/outputs/{01_reports,02_roadmaps,03_presentations}
mkdir -p second_brain/tools_internal

# Create empty files
touch second_brain/CLAUDE.md
touch second_brain/wiki/INDEX.md
touch second_brain/wiki/BACKLINKS.md
touch second_brain/wiki/CONTRADICTIONS.md
touch second_brain/tools_internal/{PROCESSING_LOG.md,HEALTH_CHECK.md,ASSET_MATRIX.md}
```

#### **Task 1.2: Download Obsidian (10 min)**
```
1. Go to https://obsidian.md
2. Download for your OS
3. Install
4. Open Obsidian
5. Create new vault → Select the "second_brain" folder you just created
6. Obsidian will automatically index all your folders
```

#### **Task 1.3: Create CLAUDE.md (60 min)**

Create file `second_brain/CLAUDE.md` with this content:

```markdown
# Claude System Instructions for AI Second Brain

## Your Role
You are the curator and knowledge synthesizer for my personal knowledge base.
Your job is to transform raw input into structured, connected assets.

## The Vault
- **raw/:** Everything I want to learn (articles, PDFs, transcripts, etc.)
- **wiki/:** Synthesized knowledge with proper connections
- **prompts/:** Reusable templates
- **playbooks/:** Automation workflows
- **tools/:** Tool evaluations & comparisons
- **outputs/:** Deliverable reports & roadmaps
- **tools_internal/:** Processing logs, health checks

## When Processing New Content

### Phase 1: Read & Analyze
1. Read the raw file completely
2. Extract 5-10 key concepts
3. Identify document type (article, case study, transcript, etc.)
4. Flag any contradictions with existing wiki

### Phase 2: Create Wiki Pages
1. Create 1-3 new wiki pages OR update existing ones
2. Each page must have YAML frontmatter:
```yaml
---
title: [Page Title]
domain: [AI/Marketing/Tools/Business]
source_documents: [List raw sources]
created_at: 2026-04-10
status: synthesis
version: 1
related_concepts: [List related wiki pages]
---
```
3. Write in markdown with [[wikilinks]] to related concepts
4. Aim for 200-500 words per page
5. Include concrete examples

### Phase 3: Generate Reusable Assets
1. **Prompt:** Extract core thinking process → Create reusable prompt
2. **Playbook:** If it's process-based → Design n8n automation
3. **Tool Update:** If it's a tool/comparison → Update relevant tool page
4. **Output:** If synthesis warrants → Create roadmap/report

### Phase 4: Update Metadata
1. Update wiki/BACKLINKS.md with new connections
2. Update wiki/INDEX.md with new pages
3. Update tools_internal/ASSET_MATRIX.md with sources → assets
4. Flag contradictions in CONTRADICTIONS.md

## Quality Standards
- Every page has YAML frontmatter
- Every page has 2+ wikilinks
- Files follow naming: 01_Concept_Name.md or YYYY-MM-DD_Descriptive_Title.md
- No page deeper than wiki/Domain/Page.md (2 levels max)
- All assets linked back to source documents

## Output Format
Always respond with:
1. Files created/updated
2. New assets generated
3. Contradictions flagged (if any)
4. Concepts recommended for expansion
5. Next priorities

---
Last Updated: 2026-04-10
```

---

### **DAY 2 (Tuesday): Write Agent Instructions - 60 Minutes**

Create file `second_brain/KNOWLEDGE_OPERATOR.md` with this content:

```markdown
# KNOWLEDGE_OPERATOR: Agent Role Definition

## Identity
You are the Knowledge Operator - the 24/7 processing engine for Tung's AI Second Brain.

## Primary Responsibilities
1. Monitor /raw folder for new files
2. Process and synthesize content
3. Transform knowledge into reusable assets
4. Maintain wiki health & consistency
5. Generate actionable outputs

## Daily Processing Workflow (09:00 AM)

When new files appear in /raw/:

1. **Detect & Read** (5 min per file)
   - Identify document type
   - Extract full content
   - Note source quality

2. **Analyze & Connect** (10 min)
   - Find key concepts
   - Query wiki for related pages
   - Identify contradictions

3. **Create Wiki Pages** (15 min)
   - Write 1-3 new pages
   - Add wikilinks
   - Include YAML metadata

4. **Generate Assets** (15 min)
   - Create prompt if conceptual
   - Design playbook if procedural
   - Update tool comparison if relevant

5. **Quality Check** (5 min)
   - Verify formatting
   - Check links work
   - Update metadata

6. **Log & Report** (5 min)
   - Update PROCESSING_LOG.md
   - Update ASSET_MATRIX.md
   - Notify owner of results

## Weekly Health Check (Sunday 20:00)

1. Find orphaned pages (no wikilinks)
2. Find contradictions between pages
3. Find incomplete pages (< 200 words)
4. Find stale content (> 3 months old)
5. Auto-fix what's fixable:
   - Add missing wikilinks
   - Consolidate duplicates
   - Archive old content
6. Generate health report
7. Flag items needing manual review

## Definition of Done (Per Asset)
- [ ] Has YAML frontmatter
- [ ] Has source documents cited
- [ ] Has 2+ wikilinks to related concepts
- [ ] Is registered in ASSET_MATRIX.md
- [ ] Is searchable via file name and tags
- [ ] Is no longer than 3 folder levels

---
Version: 1.0
Last Updated: 2026-04-10
```

---

### **DAY 3 (Wednesday): Collect Initial Sources - 120 Minutes**

**Objective:** Gather 10 diverse sources to process

**What to find:**

1. **3 Articles** (AI, Marketing, or Automation focus)
   - Save as: `raw/articles/20260410_Title.md`
   - Can copy-paste from Medium, Substack, blogs

2. **2 Case Studies**
   - Examples: How n8n was used, Zapier success story, LLM deployment
   - Save as: `raw/case_studies/20260410_CompanyName.md`

3. **2 Podcast Transcripts or Meeting Notes**
   - Can use AI transcript tools if you have video
   - Save as: `raw/transcripts/20260410_PodcastName.md`

4. **2 PDFs or Guides**
   - Examples: OpenAI API guide, Automation framework
   - Save as: `raw/pdfs/20260410_DocumentName.txt` (convert to text if needed)

5. **1 Twitter Thread or Web Clip**
   - Use Obsidian Web Clipper (free browser extension)
   - Save as: `raw/web_clips/20260410_ThreadName.md`

**Pro tip:** If you don't have these, search:
- Medium.com + "AI marketing"
- Dev.to + "automation"
- Twitter + "knowledge management"
- YouTube transcripts (use auto-generated captions)

---

### **DAY 4 (Thursday): Run First Synthesis - 90 Minutes**

#### **Step 1: Open Claude (10 min)**
Go to https://claude.ai and create a new conversation.

#### **Step 2: Upload All Raw Files (20 min)**
```
1. In Claude, use the file upload button
2. Upload all 10 files from /raw folder
3. Wait for them to upload completely
```

#### **Step 3: Run Processing Prompt (60 min for Claude to respond)**

Paste this prompt into Claude:

```
I have a personal knowledge management system called "AI Second Brain."

Read CLAUDE.md and KNOWLEDGE_OPERATOR.md for my system instructions.

[Upload CLAUDE.md]
[Upload KNOWLEDGE_OPERATOR.md]

Now read all these source documents:
[Upload all 10 files from /raw]

For each source document, perform the following:

1. Identify the key domain (AI, Marketing, Tools, Business)
2. Extract 5-10 key concepts
3. Create 1-3 wiki page outlines (don't fully write yet, just outline)
4. Suggest 1-2 reusable prompts
5. Suggest 1 playbook if applicable
6. Flag any contradictions with common knowledge

Then, provide:
1. Summary of all sources processed
2. Complete list of wiki pages to create (with outline)
3. All prompts to create (with description)
4. All playbooks to create (with workflow outline)
5. Recommended outputs (reports, roadmaps)

Format as actionable task list for me to copy into my vault.
```

**Expected output:** Claude will provide structured recommendations.

#### **Step 4: Review Recommendations (20 min)**
- Read through Claude's suggestions
- Decide which you want to implement
- Save Claude's response to a text file

---

### **DAY 5 (Friday): Build Wiki Pages - 120 Minutes**

Using Claude's recommendations from Day 4:

#### **Step 1: Create First Wiki Pages (90 min)**

For each suggested wiki page:
1. Open Obsidian
2. Create new file in appropriate folder
3. Add YAML frontmatter (copy template)
4. Write content (use Claude's outline + add your thinking)
5. Add wikilinks to related concepts

**Example process:**
```
Topic: Agent Architecture (from article on AI agents)

File: wiki/01_AI_and_LLMs/01_Agent_Architecture.md

Content:
---
title: Agent Architecture
domain: AI and LLMs
source_documents:
  - 20260410_AI_Agent_Best_Practices.md
  - 20260410_Podcast_AutomationFM_Transcript.md
created_at: 2026-04-10
status: synthesis
version: 1
related_concepts:
  - Prompt Engineering
  - Fine-Tuning
  - Deployment Patterns
---

# Agent Architecture

[Write 200-300 words synthesizing the concepts]

See also: [[Prompt Engineering]], [[Fine-Tuning]], [[Production Deployment]]
```

#### **Step 2: Create Prompts (30 min)**

For each recommended prompt:
```
File: prompts/02_analysis_and_synthesis/agent-design-prompt.md

Content:
---
title: Agent Design Prompt
source_wiki: wiki/01_AI_and_LLMs/01_Agent_Architecture.md
version: 1
---

# Agent Design Prompt

## System Prompt
"You are an expert in AI agent architecture. Your role is to help 
design agents that are reliable, scalable, and maintainable..."

## Context
[Summary from wiki page]

## Example Scenarios
[2-3 examples from source articles]

## Output Format
[How to structure the response]
```

---

### **DAY 6 (Saturday): Connect & Test RAG - 90 Minutes**

#### **Task 1: Create Obsidian Graph View (20 min)**
```
1. In Obsidian, open settings
2. Enable "Graph view" (Core Plugins)
3. Navigate to Graph view
4. You'll see wiki pages as nodes, wikilinks as connections
5. Zoom and explore connections
```

#### **Task 2: Set Up Basic RAG Query (30 min)**

In Claude, test RAG:
```
Open new Claude conversation.

Paste: "I built an Obsidian vault with these wiki pages: [list them]"

Question: "Based on the wiki pages above, what are the 
3 most important concepts for understanding AI agents?"

Claude will reference your wiki pages to answer.
This is basic RAG - Claude reads your knowledge to answer.
```

#### **Task 3: Create Master Index (40 min)**

Create file: `wiki/INDEX.md`

```markdown
# AI Second Brain - Master Index

## Domains

### 1. AI and LLMs
- [[Agent Architecture]]
- [[Prompt Engineering]]
- [[Fine-Tuning]]
- [[RAG Systems]]

### 2. Marketing and Automation
- [[Lead Generation Flows]]
- [[Email Sequences]]
- [[Content Strategy]]

### 3. Tools and Integrations
- [[OpenAI Ecosystem]]
- [[n8n Deep Dive]]
- [[Automation Comparison]]

### 4. Business Models
- [[SaaS Pricing]]
- [[Subscription Strategy]]

---

**Last Updated:** 2026-04-10
**Total Pages:** 15
**Total Concepts Connected:** 45
```

---

### **DAY 7 (Sunday): Automate & Deploy - 120 Minutes**

#### **Task 1: Set Up Processing Log (20 min)**

Create: `tools_internal/PROCESSING_LOG.md`

```markdown
# Processing Log

## 2026-04-10 (Today)

**Raw Files Processed:** 10
- Articles: 3
- Case Studies: 2
- Transcripts: 2
- PDFs: 2
- Web Clips: 1

**Wiki Pages Created:** 12
- AI and LLMs: 4 pages
- Marketing: 3 pages
- Tools: 3 pages
- Business: 2 pages

**Assets Generated:**
- Prompts: 5
- Playbooks: 2
- Tool updates: 3
- Outputs: 1 (Roadmap)

**Contradictions Found:** 1
- Location: [details]

**Next Actions:**
1. Expand playbooks (need deployment guides)
2. Create monthly synthesis
3. Set up weekly health checks

---
```

#### **Task 2: Create Asset Matrix (20 min)**

Create: `tools_internal/ASSET_MATRIX.md`

```markdown
# Asset Matrix - Knowledge to Assets Mapping

| Source | Wiki Pages | Prompts | Playbooks | Tool Eval | Outputs |
|--------|-----------|---------|-----------|-----------|---------|
| 20260410_AI_Agent_Best_Practices.md | Agent Architecture | agent-design | agent-deployment | - | Agent Strategy |
| 20260410_Case_Study.md | Lead Generation Flows | lead-gen-prompt | lead-nurture | - | Lead ROI Report |
| ... | ... | ... | ... | ... | ... |

**Totals:** 10 sources → 17 assets
**Ratio:** 1 source → 1.7 assets (target is 2+)
```

#### **Task 3: Schedule Automation (30 min)**

**Set up Daily Processing:**
- Add calendar reminder: "Daily 09:00 AM: Process raw folder"
- When reminder triggers: Check if new files in /raw
- Upload to Claude → Run KNOWLEDGE_OPERATOR prompt
- Copy results back to vault

**Set up Weekly Health Check:**
- Add calendar reminder: "Sunday 8:00 PM: Health check"
- Prompt Claude: "Run weekly health check on my vault. Find orphaned pages, contradictions, incomplete pages."

**Set up Monthly Synthesis:**
- Add calendar reminder: "1st of month 10:00 AM: Monthly synthesis"
- Prompt Claude: "Analyze all wiki pages from past month. What are top 5 concepts? What patterns emerged?"

#### **Task 4: Create Quick Reference (30 min)**

Create: `QUICK_REFERENCE.md` (in root of vault)

```markdown
# Quick Reference

## What to Do When

### When I find an article I want to learn from:
1. Save to `raw/articles/20260410_Title.md`
2. Next day, it gets processed automatically
3. Check wiki for new pages

### When I want to ask Claude about something:
1. Ask: "Based on my wiki (in the vault), what do I know about [topic]?"
2. Claude will use RAG to retrieve relevant pages
3. Answer will cite your own knowledge

### When I want to create content:
1. Use appropriate prompt from `prompts/` folder
2. Provide context from wiki
3. Generate content in minutes instead of hours

### When something's not working:
1. Check `tools_internal/HEALTH_CHECK.md` for issues
2. Look at `tools_internal/PROCESSING_LOG.md` for what was processed
3. Check wiki for contradictions

---
```

---

## ✅ End of Week 1: Verification Checklist

By Sunday night, you should have:

- [ ] Folder structure created (all 7 main folders)
- [ ] Obsidian vault set up (points to second_brain folder)
- [ ] CLAUDE.md created (system instructions)
- [ ] KNOWLEDGE_OPERATOR.md created (agent role)
- [ ] 10 initial sources in /raw folder
- [ ] 12+ wiki pages created with YAML frontmatter
- [ ] 5+ reusable prompts created
- [ ] 2+ playbooks designed
- [ ] INDEX.md created (master index)
- [ ] PROCESSING_LOG.md with first processing record
- [ ] ASSET_MATRIX.md tracking inputs → assets
- [ ] Obsidian graph view working (see connections)
- [ ] Calendar reminders set (daily, weekly, monthly)
- [ ] Claude RAG query tested successfully

---

## 🎯 Week 2 Objectives (After This Week)

- Set up vector database (Pinecone free tier)
- Implement OpenClaw agent with KNOWLEDGE_OPERATOR role
- Add 5 more sources to /raw
- Run second synthesis cycle
- Begin weekly health checks

---

## 🚀 Success Metrics

**After 1 week:**
- ✅ System is running
- ✅ First synthesis complete
- ✅ 12+ wiki pages
- ✅ 5+ reusable assets
- ✅ Obsidian graph shows connections

**After 2 weeks:**
- ✅ Automation framework in place
- ✅ 20 wiki pages
- ✅ 10+ prompts
- ✅ RAG working (Claude uses your wiki for context)

**After 1 month:**
- ✅ 40 wiki pages
- ✅ 20+ prompts
- ✅ 4+ playbooks
- ✅ Knowledge system paying dividends

---

## 📞 You're Ready

You have:
- Complete folder structure template (copy-paste)
- CLAUDE.md instructions (copy-paste)
- KNOWLEDGE_OPERATOR.md (copy-paste)
- 7-day implementation timeline
- Daily task breakdown
- Success criteria

**Start today. Move one day at a time. By next Sunday, your system is live.**

🚀
